import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.if570_lab_uts_rifqiariefwicaksana_00000073943.Models.Absensi
import com.example.if570_lab_uts_rifqiariefwicaksana_00000073943.R

class AbsensiAdapter(private val attendanceList: List<Absensi>) :
    RecyclerView.Adapter<AbsensiAdapter.AbsensiViewHolder>() {

    inner class AbsensiViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val typeTextView: TextView = itemView.findViewById(R.id.textViewType)
        val dateTextView: TextView = itemView.findViewById(R.id.textViewDate)
        val photoImageView: ImageView = itemView.findViewById(R.id.imageViewPhoto)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AbsensiViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_absensi, parent, false)
        return AbsensiViewHolder(view)
    }

    override fun onBindViewHolder(holder: AbsensiViewHolder, position: Int) {
        val attendance = attendanceList[position]
        holder.typeTextView.text = attendance.type
        holder.dateTextView.text = attendance.date

        // Load photo from the URL using Glide
        Glide.with(holder.itemView.context)
            .load(attendance.photoUrl)
            .into(holder.photoImageView)
    }

    override fun getItemCount(): Int = attendanceList.size
}
