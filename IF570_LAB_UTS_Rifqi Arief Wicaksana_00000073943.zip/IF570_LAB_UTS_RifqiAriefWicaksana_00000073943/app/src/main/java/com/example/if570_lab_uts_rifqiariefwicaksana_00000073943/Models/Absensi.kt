package com.example.if570_lab_uts_rifqiariefwicaksana_00000073943.Models

import java.io.Serializable

data class Absensi(
    val type: String,  // "check-in" or "check-out"
    val date: String,
    val photoUrl: String,
    val timestamp: String,
    ) : Serializable