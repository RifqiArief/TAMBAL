package com.example.if570_lab_uts_rifqiariefwicaksana_00000073943.Models

data class User(
    val name: String = "",
    val nim: String = ""
)
