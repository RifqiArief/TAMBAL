package com.example.if570_lab_uts_rifqiariefwicaksana_00000073943.Activities

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.if570_lab_uts_rifqiariefwicaksana_00000073943.Models.Absensi
import com.example.if570_lab_uts_rifqiariefwicaksana_00000073943.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.FirebaseApp
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.*

class HomeActivity : AppCompatActivity() {

    companion object {
        const val CAMERA_REQUEST_CODE = 100
        const val CAMERA_PERMISSION_CODE = 101
    }

    private val attendanceList = mutableListOf<Absensi>()
    private var currentPhoto: Bitmap? = null

    private lateinit var sharedPrefs: SharedPreferences
    private lateinit var imageViewPhoto: ImageView
    private lateinit var buttonAbsen: ImageButton
    private lateinit var textViewUserName: TextView
    private lateinit var textViewStatusConfirmation: TextView
    private lateinit var buttonRetake: Button
    private lateinit var buttonConfirm: Button
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContentView(R.layout.activity_home)

        auth = FirebaseAuth.getInstance()
        sharedPrefs = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)

        if (auth.currentUser == null) {
            redirectToLogin()
            return
        }

        initializeViews()
        setupListeners()
        updateUserName()
        updateDateTime()
    }

    private fun initializeViews() {
        textViewUserName = findViewById(R.id.textViewUserName)
        textViewStatusConfirmation = findViewById(R.id.textViewStatusConfirmation)
        imageViewPhoto = findViewById(R.id.imageViewPhoto)
        buttonAbsen = findViewById(R.id.ic_touch)
        buttonRetake = findViewById(R.id.buttonRetake)
        buttonConfirm = findViewById(R.id.buttonConfirm)

        findViewById<ImageButton>(R.id.buttonHistory).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<ImageButton>(R.id.buttonProfile).setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }

        hideConfirmationUI()
    }

    private fun setupListeners() {
        buttonAbsen.setOnClickListener {
            if (checkAndRequestPermissions()) openCamera()
        }
        buttonRetake.setOnClickListener { openCamera() }
        buttonConfirm.setOnClickListener { confirmAttendance() }
    }

    private fun updateUserName() {
        val userId = auth.currentUser?.uid ?: return
        FirebaseFirestore.getInstance().collection("users")
            .document(userId)
            .get()
            .addOnSuccessListener { document ->
                val userName = document.getString("name") ?: "User"
                textViewUserName.text = getString(R.string.welcome_user, userName)
                sharedPrefs.edit().putString("name", userName).apply()
            }
            .addOnFailureListener {
                textViewUserName.text = getString(R.string.welcome_user, "User")
                Toast.makeText(this, "Failed to load user name", Toast.LENGTH_SHORT).show()
            }
    }

    private fun updateDateTime() {
        val textViewDateTime = findViewById<TextView>(R.id.textViewDateTime)
        val handler = android.os.Handler(mainLooper)
        val dateTimeFormat = SimpleDateFormat("EEEE, dd/MM/yyyy HH:mm:ss", Locale.getDefault())

        handler.postDelayed(object : Runnable {
            override fun run() {
                textViewDateTime.text = dateTimeFormat.format(Date())
                handler.postDelayed(this, 1000)
            }
        }, 1000)
    }

    private fun openCamera() {
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CAMERA_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            val imageBitmap = data?.extras?.get("data") as? Bitmap
            imageBitmap?.let {
                imageViewPhoto.setImageBitmap(it)
                currentPhoto = it
                showConfirmationUI()
            } ?: Toast.makeText(this, "Failed to capture image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun bitmapToByteArray(bitmap: Bitmap): ByteArray {
        return ByteArrayOutputStream().apply {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, this)
        }.toByteArray()
    }

    private fun checkAndRequestPermissions(): Boolean {
        return if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_CODE)
            false
        } else true
    }

    private fun hideConfirmationUI() {
        imageViewPhoto.visibility = ImageView.GONE
        buttonRetake.visibility = Button.GONE
        buttonConfirm.visibility = Button.GONE
        textViewStatusConfirmation.visibility = TextView.GONE // Make sure this is visible if needed
        textViewUserName.visibility = TextView.VISIBLE  // Show the username again if it was hidden
        findViewById<ImageButton>(R.id.buttonHistory).visibility = ImageButton.VISIBLE
        findViewById<ImageButton>(R.id.buttonAbsenPlaceholder).visibility = ImageButton.VISIBLE
        findViewById<ImageButton>(R.id.buttonProfile).visibility = ImageButton.VISIBLE
        findViewById<ImageButton>(R.id.ic_touch).visibility = ImageButton.VISIBLE
    }

    private fun showConfirmationUI() {
        imageViewPhoto.visibility = ImageView.VISIBLE
        buttonRetake.visibility = Button.VISIBLE
        buttonConfirm.visibility = Button.VISIBLE
        textViewStatusConfirmation.visibility = TextView.VISIBLE
        textViewUserName.visibility = TextView.GONE
        findViewById<ImageButton>(R.id.buttonHistory).visibility = ImageButton.GONE
        findViewById<ImageButton>(R.id.buttonAbsenPlaceholder).visibility = ImageButton.GONE
        findViewById<ImageButton>(R.id.buttonProfile).visibility = ImageButton.GONE
        findViewById<ImageButton>(R.id.ic_touch).visibility = ImageButton.GONE
    }

    private fun redirectToLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    private fun confirmAttendance() {
        val userId = auth.currentUser?.uid ?: return
        val currentDate = getCurrentDate()

        // Query Firestore to check the attendance status for today
        FirebaseFirestore.getInstance().collection("attendance")
            .whereEqualTo("userId", userId)
            .whereEqualTo("date", currentDate)
            .get()
            .addOnSuccessListener { documents ->
                val hasCheckedIn = documents.any { it.getString("type") == "check-in" }
                val hasCheckedOut = documents.any { it.getString("type") == "check-out" }

                when {
                    !hasCheckedIn -> {
                        // Proceed with check-in (Absen Datang)
                        handleAttendance("check-in", currentDate)
                    }
                    hasCheckedIn && !hasCheckedOut -> {
                        // Proceed with check-out (Absen Pulang)
                        handleAttendance("check-out", currentDate)
                    }
                    else -> {
                        // Both check-in and check-out are already completed for today
                        Toast.makeText(this, "Attendance has been completed today", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Failed to check attendance: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun handleAttendance(type: String, currentDate: String) {
        currentPhoto?.let { photo ->
            val photoBytes = bitmapToByteArray(photo)
            val userId = auth.currentUser?.uid ?: return
            val timestamp = System.currentTimeMillis()
            val photoRef = FirebaseStorage.getInstance().reference
                .child("attendance_photos/$userId/$timestamp.png")

            photoRef.putBytes(photoBytes)
                .addOnSuccessListener {
                    photoRef.downloadUrl.addOnSuccessListener { uri ->
                        saveAttendance(uri.toString(), currentDate, type)

                        if (type == "check-in") {
                            sharedPrefs.edit().putBoolean("hasCheckedIn", true).apply()
                            Toast.makeText(this, "Check-in confirmed", Toast.LENGTH_SHORT).show()
                        } else {
                            sharedPrefs.edit().putBoolean("hasCheckedOut", true).apply()
                            Toast.makeText(this, "Check-out confirmed", Toast.LENGTH_SHORT).show()
                        }

                        hideConfirmationUI()
                    }
                }
                .addOnFailureListener { exception ->
                    Toast.makeText(this, "Upload failed: ${exception.message}", Toast.LENGTH_LONG).show()
                }
        }
    }

    private fun saveAttendance(photoUrl: String, date: String, type: String) {
        val userId = auth.currentUser?.uid ?: return

        val attendance = mapOf(
            "userId" to userId,
            "date" to date,
            "type" to type,  // "check-in" or "check-out"
            "photoUrl" to photoUrl
        )

        FirebaseFirestore.getInstance().collection("attendance")
            .add(attendance)
            .addOnSuccessListener {
                Toast.makeText(this, "$type saved successfully", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Failed to save $type: ${exception.message}", Toast.LENGTH_LONG).show()
            }
    }

    override fun onResume() {
        super.onResume()
        updateAbsenButtonState()
    }

    private fun updateAbsenButtonState() {
        val lastAbsenDate = sharedPrefs.getString("lastAbsenDate", "") ?: ""
        val currentDate = getCurrentDate()

        if (lastAbsenDate != currentDate) resetAttendance()

        val hasCheckedIn = sharedPrefs.getBoolean("hasCheckedIn", false)
        val hasCheckedOut = sharedPrefs.getBoolean("hasCheckedOut", false)

        when {
            !hasCheckedIn -> {
                // Ready for check-in (Absen Datang)
                textViewStatusConfirmation.text = "Time to Check In"
                buttonAbsen.isEnabled = true
            }
            hasCheckedIn && !hasCheckedOut -> {
                // Ready for check-out (Absen Pulang)
                textViewStatusConfirmation.text = "Time to Check Out"
                buttonAbsen.isEnabled = true
            }
            else -> {
                // Attendance completed for the day
                textViewStatusConfirmation.text = "Attendance completed for today"
                buttonAbsen.isEnabled = false
            }
        }
    }

    private fun resetAttendance() {
        sharedPrefs.edit().apply {
            putBoolean("hasCheckedIn", false)
            putBoolean("hasCheckedOut", false)
            putString("lastAbsenDate", getCurrentDate())
            apply()
        }
        textViewStatusConfirmation.text = "Ready to Check In"
        buttonAbsen.isEnabled = true
    }

    private fun getCurrentDate(): String {
        return SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
    }

}
