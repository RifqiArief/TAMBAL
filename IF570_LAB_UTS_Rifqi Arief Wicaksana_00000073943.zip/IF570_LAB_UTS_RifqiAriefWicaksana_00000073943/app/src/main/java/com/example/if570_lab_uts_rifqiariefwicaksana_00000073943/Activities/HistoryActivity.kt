package com.example.if570_lab_uts_rifqiariefwicaksana_00000073943.Activities

import AbsensiAdapter
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.if570_lab_uts_rifqiariefwicaksana_00000073943.Models.Absensi
import com.example.if570_lab_uts_rifqiariefwicaksana_00000073943.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class HistoryActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var absensiAdapter: AbsensiAdapter
    private val attendanceList = mutableListOf<Absensi>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        initializeRecyclerView()
        loadAttendanceData()

        // Save this page as the last visited page
        saveLastPage("HistoryActivity")
    }

    // Initialize the RecyclerView
    private fun initializeRecyclerView() {
        recyclerView = findViewById(R.id.recyclerViewRiwayat)
        recyclerView.layoutManager = LinearLayoutManager(this)
        absensiAdapter = AbsensiAdapter(attendanceList)
        recyclerView.adapter = absensiAdapter
    }

    // Load attendance data from Firestore
    private fun loadAttendanceData() {
        val userId = FirebaseAuth.getInstance().currentUser?.uid
        if (userId != null) {
            FirebaseFirestore.getInstance().collection("attendance")
                .whereEqualTo("userId", userId)
                .get()
                .addOnSuccessListener { documents ->
                    attendanceList.clear()  // Clear previous data
                    for (document in documents) {
                        val type = document.getString("type") ?: "Unknown"
                        val date = document.getString("date") ?: "Unknown"
                        val photoUrl = document.getString("photoUrl") ?: ""

                        // Add attendance record to the list
                        attendanceList.add(Absensi(type, date, photoUrl, timestamp = ""))
                    }
                    absensiAdapter.notifyDataSetChanged()

                    if (attendanceList.isEmpty()) {
                        Toast.makeText(this, "No attendance records found", Toast.LENGTH_SHORT).show()
                    }
                }
                .addOnFailureListener { exception ->
                    Log.e("HistoryActivity", "Error fetching attendance: ${exception.message}")
                    Toast.makeText(this, "Failed to load attendance data", Toast.LENGTH_SHORT).show()
                }
        } else {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
        }
    }

    // Save the last visited page in SharedPreferences
    private fun saveLastPage(pageName: String) {
        val sharedPrefs = getSharedPreferences("LastPagePrefs", Context.MODE_PRIVATE)
        sharedPrefs.edit().putString("lastPage", pageName).apply()
    }

    // Handle back press with a call to HomeActivity
    override fun onBackPressed() {
        val intent = Intent(this, HomeActivity::class.java)
        startActivity(intent)
        finish()
        super.onBackPressed()  // Ensure proper back press handling
    }
}
