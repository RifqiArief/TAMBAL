package com.example.if570_lab_uts_rifqiariefwicaksana_00000073943.Utils

class FirebaseUtils {
}