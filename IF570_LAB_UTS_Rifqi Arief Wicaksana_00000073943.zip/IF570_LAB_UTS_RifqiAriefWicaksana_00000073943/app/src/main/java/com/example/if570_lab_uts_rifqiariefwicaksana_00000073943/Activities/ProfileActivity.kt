package com.example.if570_lab_uts_rifqiariefwicaksana_00000073943.Activities

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.if570_lab_uts_rifqiariefwicaksana_00000073943.Models.User
import com.example.if570_lab_uts_rifqiariefwicaksana_00000073943.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val editTextName = findViewById<EditText>(R.id.editTextName)
        val editTextNim = findViewById<EditText>(R.id.editTextNim)
        val buttonSaveProfile = findViewById<Button>(R.id.buttonSaveProfile)

        // Load profile data from Firestore
        loadUserProfile()

        buttonSaveProfile.setOnClickListener {
            val name = editTextName.text.toString().trim()
            val nim = editTextNim.text.toString().trim()

            if (name.isEmpty() || nim.isEmpty()) {
                Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show()
            } else {
                // Save user profile to Firestore
                saveUserProfile(name, nim)
            }
        }
    }

    private fun saveUserProfile(nama: String, nim: String) {
        val user = User(nama, nim)
        val userId = FirebaseAuth.getInstance().currentUser?.uid
        if (userId != null) {
            FirebaseFirestore.getInstance().collection("users")
                .document(userId)
                .set(user)
                .addOnSuccessListener {
                    Toast.makeText(this, "Profile Updated Successfully", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Failed to Update Profile", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun loadUserProfile() {
        val userId = FirebaseAuth.getInstance().currentUser?.uid
        userId?.let {
            FirebaseFirestore.getInstance().collection("users")
                .document(it)
                .get()
                .addOnSuccessListener { documentSnapshot ->
                    val user = documentSnapshot.toObject(User::class.java)
                    user?.let { usr ->
                        findViewById<EditText>(R.id.editTextName).setText(usr.name)
                        findViewById<EditText>(R.id.editTextNim).setText(usr.nim)
                    }
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Failed to Load Profile", Toast.LENGTH_SHORT).show()
                }
        }
    }
}
