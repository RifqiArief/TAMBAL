package com.example.kelompok2.DataModels

data class CarBrandModel(
    val brandName: String = "n/a",
    val imageUrl: String = "n/a"
)
