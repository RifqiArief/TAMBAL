package com.example.kelompok2.ViewModels

import androidx.lifecycle.ViewModel

class NotificationsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}