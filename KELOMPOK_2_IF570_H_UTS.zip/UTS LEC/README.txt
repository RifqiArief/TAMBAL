        <TAMBAL>
aplikasi TAMBAL memiliki kepanjangan Tambal Ban Online, aplikasi ini berfungsi sebagai jembatan untuk pengguna kendaraan yang memiliki masalah pada kendaraannya yang mogogk ditengah jalan, ban bocor, tidak ada waktu ke bengkel. Tujuan aplikasi ini adalah mempermudah orang-orang untuk mendapatkan perbaikan pada kendaraanya karena pada aaplikasi ini mechanic atau bengkelah yang akan mendatangi client, selain itu kita juga bisa book tempat di bengkel agar ketersediaan bengkel terjamin dan mengestimasi lamanya perbaikan.
        <TAMBAL>
    Fidel Brian Dava (00000073866)
    Rifqi Arief Wicaksana (00000073943)
    Damar Nur Rafly (00000074723)
    Jonathan joshua (00000074760)


1. aplikasi ini dibuat menggunakan bahasa kotlin dengan menggunakan firebase sebagai databasenya
2. untuk firebase kita sudah menggunakan fitur auth dan firestore untuk menyokong fungsi dari aplikasi
3. saat ini aplikasi ini memiliki beberapa fitur seperti login, register, profile update 
4. saat ini aplikasi ini juga memiliki beberapa halaman seperti halaman login, register, home page, notification, profile, placeholder untuk maps
